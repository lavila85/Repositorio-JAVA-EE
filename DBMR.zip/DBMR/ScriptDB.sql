SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE SCHEMA IF NOT EXISTS `DB_UCC` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `DB_UCC` ;

-- -----------------------------------------------------
-- Table `DB_UCC`.`Estudiantes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DB_UCC`.`Estudiantes` (
  `idEstudiante` INT NOT NULL,
  `Nombres` VARCHAR(45) NULL,
  `Apellidos` VARCHAR(45) NULL,
  PRIMARY KEY (`idEstudiante`),
  UNIQUE INDEX `idEstudiante_UNIQUE` (`idEstudiante` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `DB_UCC`.`Cursos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DB_UCC`.`Cursos` (
  `idCurso` INT NOT NULL,
  `Nombre` VARCHAR(45) NULL,
  `Descripcion` VARCHAR(45) NULL,
  PRIMARY KEY (`idCurso`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `DB_UCC`.`Inscripciones`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DB_UCC`.`Inscripciones` (
  `idInscripcion` INT NOT NULL,
  `idEstudiante` INT NULL,
  `idCurso` INT NULL,
  `Fecha` DATE NULL,
  `Estudiantes_idEstudiante` INT NOT NULL,
  `Cursos_idCurso` INT NOT NULL,
  PRIMARY KEY (`idInscripcion`),
  INDEX `fk_Inscripciones_Estudiantes_idx` (`Estudiantes_idEstudiante` ASC),
  INDEX `fk_Inscripciones_Cursos1_idx` (`Cursos_idCurso` ASC),
  CONSTRAINT `fk_Inscripciones_Estudiantes`
    FOREIGN KEY (`Estudiantes_idEstudiante`)
    REFERENCES `DB_UCC`.`Estudiantes` (`idEstudiante`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Inscripciones_Cursos1`
    FOREIGN KEY (`Cursos_idCurso`)
    REFERENCES `DB_UCC`.`Cursos` (`idCurso`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
